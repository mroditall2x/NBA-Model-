import pandas as pd, numpy as np
from slate_names import norm
q=pd.read_parquet('repo/nba/player_box/parquet/player_box_2027.parquet'); q=q[q.game_date.astype(str)=='2026-10-23']
fc=[c for c in q.columns if 'free_throws_made' in c][0]
q['k']=q.athlete_display_name.map(norm)
q['min']=pd.to_numeric(q.minutes,errors='coerce')
def stat(r,s):
    P,R,A,S,B=r.points,r.rebounds,r.assists,r.steals,r.blocks
    return {'PTS':P,'REB':R,'AST':A,'STL':S,'BLK':B,'RA':R+A,'PR':P+R,'PA':P+A,'PRA':P+R+A,'Stl+Blk':S+B,'FTM':r[fc],
            'FS':P+1.2*R+1.5*A+3*B+3*S-r.turnovers}[s]
card=[('clean','Zach LaVine','REB',3.5,'Less'),('clean','Jalen Duren','RA',12,'Less'),('clean','Rudy Gobert','RA',13.5,'Less'),
('clean','Kyle Kuzma','RA',7.5,'Less'),('clean','Ja Morant','RA',9.5,'Less'),('clean','Jayson Tatum','RA',15.5,'Less'),
('clean','Myles Turner','RA',7.5,'Less'),('clean','Duncan Robinson','STL',0.5,'Less'),('clean','Derrick Jones Jr.','AST',1.5,'Less'),
('clean',"De'Andre Hunter",'RA',5.5,'Less'),
('goblin','Jakob Poeltl','PTS',3.5,'More'),('goblin','Moussa Diabaté','PTS',3.5,'More'),('goblin','Dyson Daniels','RA',7.5,'More'),
('goblin','Jayson Tatum','PTS',17.5,'More'),('goblin','Andrew Wiggins','RA',3.5,'More'),('goblin','Jrue Holiday','PR',8.5,'More'),('goblin','Jaxson Hayes','PR',8.5,'More'),
('demon','Andrew Wiggins','Stl+Blk',2.5,'More'),('demon','Jabari Smith Jr.','BLK',0.5,'More'),
('deon','Ja Morant','AST',6.5,'More'),('deon-drummond','Andre Drummond','BLK',0.5,'More'),('deon-drummond','Andre Drummond','REB',7.5,'More'),
('deon-drummond','Andre Drummond','FTM',0.5,'More'),
('slip','Tyrese Haliburton','RA',13.5,'More'),('slip','Trae Young','RA',12.5,'More'),('slip','Ausar Thompson','FS',30,'More'),('slip','Fred VanVleet','AST',6.5,'More')]
rows=[]
for tier,n,s,l,side in card:
    m=q[q.k==norm(n)]
    if not len(m): rows.append((tier,n,s,l,side,None,None,'DNP/not found')); continue
    r=m.iloc[0]; a=stat(r,s)
    res='WIN' if ((a>l) if side=='More' else (a<l)) else ('PUSH' if a==l else 'LOSS')
    rows.append((tier,n,s,l,side,round(float(a),1),r['min'],res))
G=pd.DataFrame(rows,columns=['tier','player','stat','line','side','actual','min','result'])
print(G.to_string(index=False))
dd=q[q.k==norm('Andre Drummond')].iloc[0]; print('Drummond line',dd[['min','points','rebounds','assists','blocks','steals',fc]].to_dict())
G.to_csv('slate/1023/card_graded.csv',index=False)
