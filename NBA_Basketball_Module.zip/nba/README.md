# NBA Prop Model (Deon)
Monte Carlo possession sim for NBA player props, sides and totals. Data: hoopR (sportsdataverse/hoopr-nba-data). Lines: Outlier (scraped from the logged-in browser) or any odds feed in the same format.

## Daily run
1. `git clone --depth 1 https://github.com/sportsdataverse/hoopr-nba-data repo` (then `git pull` daily, ~noon CT)
2. Lines -> `slate/MMDD/lines.json` (game lines) + `slate/MMDD/props_p1.txt` (`game|player|STAT|line|over_odds|under_odds`) + `pp_compact.json`
3. Outs -> `slate/YYYY-MM-DD_out.json`; questionable -> `slate/MMDD/gtd.json`
4. `python3 auto_minutes.py YYYY-MM-DD slate/YYYY-MM-DD_rot_last.json && python3 rot_blend.py YYYY-MM-DD 0.6` (fix starters by hand)
5. `NO_OUTGUESS=1 SAVE_SIM=1 python3 slate1021.py YYYY-MM-DD slate/MMDD` -> `python3 blend_minutes.py slate/MMDD` -> rerun with `--blend`
6. `python3 card_slate.py slate/MMDD` -> board_all.csv;  `python3 dvp.py slate/MMDD` for matchup factors
7. Grade with grade1023.py pattern -> append graded_log.csv

## Card rules (see SKILL.md for full lessons)
- Show adjusted % = 0.5 + 0.6*(model-0.5); card bar 58%; star/big Unders (35+ min) need 62%.
- |minutes gap| <= 4; no Unders if gap > +2; no Overs if gap < -2; skip new-team / small-sample players.
- Points slot every game; goblins are the best-calibrated tier; steals alone = coin flip, blocks / stl+blk OK.
- Full game: skip totals/spreads when model is 6+ pts off market.
- Tag every pick: PrizePicks / Underdog / Kalshi. Never price off Fliff.
