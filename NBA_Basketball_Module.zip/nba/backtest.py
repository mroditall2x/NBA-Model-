"""Rolling backtest on 2025-26: only data before each game; actual active players (like knowing the injury report);
expected minutes from history. Market mode (closing spread/total) for props; model mode numbers recorded for sides."""
import sys, numpy as np, pandas as pd, nba_sim as S

N = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
STEP = int(sys.argv[2]) if len(sys.argv) > 2 else 4
p, t = S.load((2025, 2026)); pri = S.pos_priors(p)
L = pd.read_parquet(f'{S.ROOT}/betting_lines/closing_lines_odds_api.parquet')[['game_id', 'home_point', 'over_under']]
H = t[(t.season == 2026) & (t.home_away == 'home') & (t.game_date >= '2025-11-20')].merge(L, on='game_id').iloc[::STEP]
STATS = ['pts', 'reb', 'ast', 'pra', 'pr', 'pa', 'ra', 'stl', 'blk', 'stocks', 'fg3m']
grow, prow = [], []
for k, g in enumerate(H.itertuples()):
    lg = S.league(t[(t.game_date < g.game_date) & (t.game_date >= g.game_date - pd.Timedelta(days=365))])
    act = p[p.game_id == g.game_id]
    try:
        hs = S.build_side(p, t, g.team, g.game_date, lg, pri, players=act[act.team == g.team].pid.tolist())
        as_ = S.build_side(p, t, g.opp, g.game_date, lg, pri, players=act[act.team == g.opp].pid.tolist())
        G = S.Game(hs, as_, lg, np.random.default_rng(k))
        sc, b = G.run(N, spread=g.home_point, total=g.over_under)
    except Exception as e:
        print('skip', g.game_id, e); continue
    mh, ma = G.model_pts
    grow.append(dict(game_id=g.game_id, date=g.game_date, home=g.team, away=g.opp, line=g.home_point, ou=g.over_under,
                     model_margin=mh - ma, model_total=mh + ma, act_margin=g.pts - g.o_pts, act_total=g.pts + g.o_pts,
                     sim_margin_sd=(sc[:, 0] - sc[:, 1]).std()))
    df = S.to_frame(G, b)
    a = act.assign(pra=act.pts + act.reb + act.ast, pr=act.pts + act.reb, pa=act.pts + act.ast, ra=act.reb + act.ast,
                   stocks=act.stl + act.blk).set_index('name')
    for (team, pl), x in df.groupby(['team', 'player']):
        if pl not in a.index: continue
        r = a.loc[pl]
        if isinstance(r, pd.DataFrame): r = r.iloc[0]
        prof = next(q for q in (hs.players + as_.players) if q['name'] == pl)
        row = dict(game_id=g.game_id, player=pl, exp_min=prof['mu'], act_min=r['min'], sim_min=x['min'].mean())
        for st in STATS:
            v = x[st].values; y = r[st]
            row[f'{st}_mean'] = v.mean(); row[f'{st}_act'] = y
            row[f'{st}_pit'] = (v < y).mean() + 0.5 * (v == y).mean()
            ln = np.floor(np.median(v)) + 0.5            # a synthetic half-point line at the sim median
            row[f'{st}_pover'] = (v > ln).mean(); row[f'{st}_hit'] = float(y > ln); row[f'{st}_ln'] = ln
        # naive baseline: last-10 per-game average
        hist = p[(p.pid == prof['pid']) & (p.game_date < g.game_date)].tail(10)
        hist = hist.assign(pra=hist.pts + hist.reb + hist.ast, pr=hist.pts + hist.reb, pa=hist.pts + hist.ast,
                           ra=hist.reb + hist.ast, stocks=hist.stl + hist.blk)
        for st in STATS:
            row[f'{st}_l10'] = hist[st].mean() if len(hist) else np.nan
        prow.append(row)
    if k % 25 == 0:
        print(k, len(H), flush=True)
import os; tag=os.environ.get('TAG','');pd.DataFrame(grow).to_csv(f'bt_games{tag}.csv', index=False)
pd.DataFrame(prow).to_csv(f'bt_players{tag}.csv', index=False)
print('done', len(grow), len(prow))
